package kz.kbtu.taroapp;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView tvProfText;
    private Button btnStart;
    private ImageView ivProf;
    private String[] profs = {"Архитектор", "Спасатель", "Генетик", "Пожарный", "Космонавт", "Хирург", "Врач", "Частный детектив", "Следователь", "Астронавт", "Системный администратор"};
    private int[] photos = {R.drawable.architect, R.drawable.rescue, R.drawable.genetic, R.drawable.fireman, R.drawable.kosmonavt, R.drawable.hirurg, R.drawable.vrach, R.drawable.detektiv, R.drawable.sledovatel, R.drawable.astrounaut, R.drawable.sysadmin};
    private boolean isStarted;
    private Random random;
    private Handler handler;
    private Runnable runnable;
    private Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        tvProfText.setText(profs[0]);
        ivProf.setImageResource(photos[0]);
        random = new Random();
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                update();
            }
        };
    }

    private void update() {
        int idx = random.nextInt(profs.length);
        ivProf.setImageResource(photos[idx]);
        tvProfText.setText(profs[idx]);
    }

    private void bindViews() {
        tvProfText = findViewById(R.id.tv_prof_text);
        btnStart = findViewById(R.id.btn_start);
        ivProf = findViewById(R.id.iv_prof);
        btnStart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_start:
                if(!isStarted){
                    start();
                }
                else
                    stop();
                break;
        }
    }

    private void stop() {
        isStarted = false;
        btnStart.setText("Start");
        timer.cancel();
    }

    private void start() {
        isStarted = true;
        btnStart.setText("Stop");
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                postUpdate();
            }
        }, 0, 50);

    }

    private void postUpdate() {
        handler.post(runnable);
    }
}
