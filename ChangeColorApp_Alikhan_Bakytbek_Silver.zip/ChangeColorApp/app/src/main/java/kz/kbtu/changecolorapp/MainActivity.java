package kz.kbtu.changecolorapp;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button btnChangeColor;
    private View v;
    private Random rand;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rand = new Random();
        btnChangeColor = findViewById(R.id.btn_change_color);
        v = findViewById(R.id.root_view);

        v.setBackgroundColor(getNextBackgroundColor());
        btnChangeColor.setBackgroundColor(getNextButtonColor());

        btnChangeColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                v.setBackgroundColor(getNextBackgroundColor());
                btnChangeColor.setBackgroundColor(getNextButtonColor());
            }
        });
    }
    private int getNextButtonColor(){
        float[] hsv = new float[3];
        hsv[0] = 167 + rand.nextInt(84);
        hsv[1] = 1.0f;
        Log.d("HSV", hsv[1] + "");
        hsv[2] = 0.2f + rand.nextFloat();
        Log.d("HSV", hsv[2] + "");
        return Color.HSVToColor(hsv);
    }

    private int getNextBackgroundColor(){
        float[] hsv = new float[3];
        hsv[0] = 70 + rand.nextInt(96);
        hsv[1] = 1.0f;
        hsv[2] = 0.2f + rand.nextFloat();
        return Color.HSVToColor(hsv);
    }
}


