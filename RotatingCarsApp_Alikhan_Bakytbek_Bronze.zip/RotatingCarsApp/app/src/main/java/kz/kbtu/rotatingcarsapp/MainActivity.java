package kz.kbtu.rotatingcarsapp;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private ImageView iv1;
    private ImageView iv2;
    private ImageView iv3;
    private ImageView iv4;
    private Button btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
    }

    private void bindViews() {
        iv1 = findViewById(R.id.iv_1);
        iv2 = findViewById(R.id.iv_2);
        iv3 = findViewById(R.id.iv_3);
        iv4 = findViewById(R.id.iv_4);
        btnNext = findViewById(R.id.button_next);
        btnNext.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.button_next:
                changePictures();
                break;
        }
    }

    private void changePictures() {
        Drawable pic1 = iv1.getDrawable();
        Drawable pic2= iv2.getDrawable();
        Drawable pic3 = iv3.getDrawable();
        Drawable pic4 = iv4.getDrawable();

        iv1.setImageDrawable(pic4);
        iv2.setImageDrawable(pic1);
        iv3.setImageDrawable(pic2);
        iv4.setImageDrawable(pic3);
    }


}
