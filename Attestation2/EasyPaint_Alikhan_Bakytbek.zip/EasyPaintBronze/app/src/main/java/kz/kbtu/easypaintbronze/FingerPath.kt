package kz.kbtu.easypaintbronze

import android.graphics.Path

/**
 * Created by abakh on 13-Mar-18.
 */
class FingerPath(sW : Int, p : Path) {
    var strokeWidth = sW
    var path = p



}