package kz.kbtu.pixabaysilver.helpers

data class PixabayVideos(var tags : String, var pictureId : String, var videoUrl : String, var views : Int, var favorites : Int, var likes : Int, var user : String)
