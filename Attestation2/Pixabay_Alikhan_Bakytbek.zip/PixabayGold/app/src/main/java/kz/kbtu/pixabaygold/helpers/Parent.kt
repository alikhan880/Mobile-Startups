package kz.kbtu.pixabaygold.helpers

interface Parent {
}