package kz.kbtu.taroapp;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView tvProfText;
    private Button btnStart;
    private ImageView ivProf;
    private String[] profs = {"Архитектор", "Спасатель", "Генетик", "Пожарный", "Космонавт", "Хирург", "Врач", "Частный детектив", "Следователь", "Астронавт", "Системный администратор"};
    private int[] photos = {R.drawable.architect, R.drawable.rescue, R.drawable.genetic, R.drawable.fireman, R.drawable.kosmonavt, R.drawable.hirurg, R.drawable.vrach, R.drawable.detektiv, R.drawable.sledovatel, R.drawable.astrounaut, R.drawable.sysadmin};
    private Random random;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        random = new Random();
        int firstIdx = random.nextInt(profs.length);
        tvProfText.setText(profs[firstIdx]);
        ivProf.setImageResource(photos[firstIdx]);
    }

    private void bindViews() {
        tvProfText = findViewById(R.id.tv_prof_text);
        btnStart = findViewById(R.id.btn_start);
        ivProf = findViewById(R.id.iv_prof);
        btnStart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_start:
                start();
                break;
        }
    }

    private void start() {
        int num = random.nextInt(20);
        btnStart.setEnabled(false);
        CountDownTimer timer = new CountDownTimer((num * 100 + 1), 50) {
            @Override
            public void onTick(long l) {
                int idx = random.nextInt(profs.length);
                tvProfText.setText(profs[idx]);
                ivProf.setImageResource(photos[idx]);
            }

            @Override
            public void onFinish() {
                btnStart.setEnabled(true);
            }
        }.start();
    }
}
